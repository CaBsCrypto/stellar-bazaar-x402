/** Token-only private access checks. No signer, buyer store or financial tool. */
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StreamableHTTPClientTransport} from '@modelcontextprotocol/sdk/client/streamableHttp.js';

export const AGENT_ACCESS_ORIGIN='https://bazaar.browns.studio';
const tools=new Set(['get_bazaar_identity','get_bazaar_capabilities','list_market_orders']);
const ownerPattern=/^ow_[a-f0-9]{32}$/,agentPattern=/^agent_[a-f0-9]{32}$/,uuidPattern=/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
const nativeCodes=new Set(['UNAUTHORIZED','FORBIDDEN','INVALID_REQUEST','INVALID_CURSOR','WORKSPACES_DISABLED','WORKSPACE_UNAVAILABLE','WORKSPACE_CAPACITY','WORKSPACE_RATE_LIMIT','MARKET_DISABLED','MARKET_UNAVAILABLE','MARKET_CONFIGURATION_INCOMPLETE','FREE_DEMO_REQUEST_LIMIT','FREE_DEMO_BUDGET_UNAVAILABLE','RESPONSE_TOO_LARGE','CONTINUOUS_CONTROL_TRANSPORT_BUDGET']);
export class AgentAccessError extends Error{
 constructor(code,{httpStatus,retryAfter}={}){super(code);this.name='AgentAccessError';this.code=code;this.publicCode=code;if(Number.isInteger(httpStatus))this.httpStatus=httpStatus;if(Number.isSafeInteger(retryAfter)&&retryAfter>=0&&retryAfter<=86400)this.retryAfter=retryAfter;}
}
const fail=code=>{throw new AgentAccessError(code);};
const object=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
const only=(value,keys)=>object(value)&&Object.keys(value).every(key=>keys.includes(key));
export function agentAccessOrigin(origin=AGENT_ACCESS_ORIGIN){
 let url;try{url=new URL(origin);}catch{fail('AGENT_ORIGIN_REJECTED');}
 if(typeof origin!=='string'||url.origin!==origin||url.username||url.password||url.pathname!=='/'||url.search||url.hash||!(origin===AGENT_ACCESS_ORIGIN||url.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(url.hostname)))fail('AGENT_ORIGIN_REJECTED');
 return origin;
}
export function validateAgentHistoryOptions(options={}){
 if(!only(options,['limit','cursor']))fail('AGENT_HISTORY_OPTIONS_REJECTED');
 const {limit=10,cursor}=options;
 if(!Number.isInteger(limit)||limit<1||limit>20||cursor!==undefined&&(typeof cursor!=='string'||!/^[a-zA-Z0-9_-]{1,512}$/.test(cursor)))fail('AGENT_HISTORY_OPTIONS_REJECTED');
 return {limit,...(cursor===undefined?{}:{cursor})};
}
/** Used by the transport before dispatch; callers cannot select other tools. */
export function validateAgentAccessRpcRequest(rpc){
 if(!only(rpc,['jsonrpc','id','method','params'])||rpc.jsonrpc!=='2.0'||typeof rpc.method!=='string')fail('AGENT_RPC_REJECTED');
 if(rpc.id!==undefined&&!(typeof rpc.id==='string'||Number.isSafeInteger(rpc.id)))fail('AGENT_RPC_REJECTED');
 if(rpc.method==='initialize'){
  if(!object(rpc.params)||typeof rpc.params.protocolVersion!=='string'||!object(rpc.params.capabilities)||!object(rpc.params.clientInfo))fail('AGENT_RPC_REJECTED');return rpc;
 }
 if(rpc.method==='notifications/initialized'){if(rpc.id!==undefined||rpc.params!==undefined&&(!only(rpc.params,['_meta'])))fail('AGENT_RPC_REJECTED');return rpc;}
 if(rpc.method==='tools/list'){if(rpc.params!==undefined&&Object.keys(rpc.params).length)fail('AGENT_RPC_REJECTED');return rpc;}
 if(rpc.method!=='tools/call'||!only(rpc.params,['name','arguments','_meta'])||!tools.has(rpc.params.name))fail('AGENT_RPC_REJECTED');
 const args=rpc.params.arguments??{};
 if(rpc.params.name==='list_market_orders')validateAgentHistoryOptions(args);else if(!object(args)||Object.keys(args).length)fail('AGENT_RPC_REJECTED');
 return rpc;
}
function rejected(body,httpStatus,retryAfter){const code=body?.error?.code??body?.code;return new AgentAccessError(nativeCodes.has(code)?code:'AGENT_TOOL_REJECTED',{httpStatus,retryAfter});}
function toolBody(result){
 if(!object(result))fail('AGENT_RESPONSE_REJECTED');
 let text,body;
 try{const entries=result.content?.filter(item=>item.type==='text');if(entries?.length===1)text=JSON.parse(entries[0].text);body=result.structuredContent??text;}catch{fail('AGENT_RESPONSE_REJECTED');}
 if(!object(body)||result.structuredContent!==undefined&&text!==undefined&&JSON.stringify(text)!==JSON.stringify(body))fail('AGENT_RESPONSE_REJECTED');
 const status=body.httpStatus??body.http?.status;
 if(result.isError===true||body.error||status!==undefined&&status!==200)throw rejected(body,status,body.retryAfter??body.http?.retryAfter);
 return body;
}

export function createAgentAccessClient(options){
 if(!only(options,['origin','agentAccess','expectedOwnerId','expectedGeneration','fetchImpl','timeoutMs','maxResponseBytes']))fail('AGENT_CLIENT_OPTIONS_REJECTED');
 const {origin=AGENT_ACCESS_ORIGIN,agentAccess,expectedOwnerId,expectedGeneration,fetchImpl=fetch,timeoutMs=12000,maxResponseBytes=262144}=options;
 agentAccessOrigin(origin);
 if(typeof agentAccess!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(agentAccess)||!ownerPattern.test(expectedOwnerId??'')||expectedGeneration!==undefined&&(!Number.isSafeInteger(expectedGeneration)||expectedGeneration<1)||typeof fetchImpl!=='function'||!Number.isSafeInteger(timeoutMs)||timeoutMs<1||timeoutMs>15000||!Number.isSafeInteger(maxResponseBytes)||maxResponseBytes<1||maxResponseBytes>262144)fail('AGENT_CLIENT_OPTIONS_REJECTED');
 const endpoint=new URL('/api/mcp',origin);let token=agentAccess,closed=false,fault,connected=false,verifiedIdentity,connection,fetchTail=Promise.resolve(),operationTail=Promise.resolve();
 const assertOpen=()=>{if(fault)throw fault;if(closed)fail('AGENT_CLIENT_CLOSED');};
 const stop=error=>{fault=error instanceof AgentAccessError?error:new AgentAccessError('AGENT_REQUEST_UNCONFIRMED');return fault;};
 const drain=async()=>{await Promise.resolve();await fetchTail;};
 async function dispatch(input,init={}){
  assertOpen();
  const target=new URL(input instanceof Request?input.url:String(input));
  if(target.href!==endpoint.href)fail('AGENT_ENDPOINT_REJECTED');
  const method=(init.method??(input instanceof Request?input.method:'GET')).toUpperCase();
  // SDK1.30's optional SSE attempt is unsupported locally, with zero native IO.
  if(method==='GET')return new Response(null,{status:405,headers:{Allow:'POST'}});
  if(method!=='POST'||typeof init.body!=='string'||Buffer.byteLength(init.body)>65536)fail('AGENT_RPC_REJECTED');
  let rpc;try{rpc=JSON.parse(init.body);}catch{fail('AGENT_RPC_REJECTED');}validateAgentAccessRpcRequest(rpc);
  const headers=new Headers(init.headers);if(headers.has('cookie')||headers.has('proxy-authorization'))fail('AGENT_HEADERS_REJECTED');headers.set('authorization','Bearer '+token);
  const abort=new AbortController(),signals=[abort.signal,...(init.signal?[init.signal]:[])];let timer;
  const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{abort.abort();reject(new AgentAccessError('AGENT_REQUEST_UNCONFIRMED'));},timeoutMs);});
  try{return await Promise.race([(async()=>{
   const response=await fetchImpl(endpoint,{...init,method:'POST',headers,credentials:'omit',redirect:'error',cache:'no-store',signal:AbortSignal.any(signals)});
   if(response.redirected||response.url&&new URL(response.url).href!==endpoint.href||Buffer.byteLength(JSON.stringify([...response.headers]))>16384)fail('AGENT_RESPONSE_REJECTED');
   const chunks=[];let bytes=0;const reader=response.body?.getReader();
   if(reader)try{for(;;){const part=await reader.read();if(part.done)break;bytes+=part.value.byteLength;if(bytes>maxResponseBytes){void reader.cancel();fail('AGENT_RESPONSE_TOO_LARGE');}chunks.push(part.value);}}finally{reader.releaseLock();}
   const raw=Buffer.concat(chunks),retry=response.headers.get('retry-after'),retryAfter=/^\d{1,5}$/.test(retry??'')?Number(retry):undefined;
   if(!response.ok){let body;try{body=JSON.parse(raw.toString('utf8'));}catch{}throw rejected(body,response.status,retryAfter);}
   const safeHeaders=new Headers(response.headers);safeHeaders.delete('set-cookie');return new Response(raw.length?raw:null,{status:response.status,headers:safeHeaders});
  })(),timeout]);}finally{clearTimeout(timer);}
 }
 const guardedFetch=(input,init)=>{const task=fetchTail.then(()=>dispatch(input,init)).catch(error=>{throw stop(error);});fetchTail=task.then(()=>{},()=>{});return task;};
 const client=new Client({name:'bazaar-agent-access',version:'1.0.0'});
 client.onerror=()=>{};
 const transport=new StreamableHTTPClientTransport(endpoint,{fetch:guardedFetch,requestInit:{credentials:'omit'},reconnectionOptions:{maxRetries:0,initialReconnectionDelay:1000,maxReconnectionDelay:1000,reconnectionDelayGrowFactor:1}});
 async function ensureConnected(){
  assertOpen();if(connected)return;
  connection??=(async()=>{await client.connect(transport);await drain();const listed=await client.listTools();await drain();if(!Array.isArray(listed.tools)||[...tools].some(name=>!listed.tools.some(tool=>tool.name===name)))fail('AGENT_REQUIRED_TOOLS_MISSING');connected=true;})();await connection;
 }
 async function call(name,args={}){assertOpen();await ensureConnected();try{const result=await client.callTool({name,arguments:args});await drain();return toolBody(result);}catch(error){throw stop(error);}}
 async function identity(){
  const body=await call('get_bazaar_identity');
  if(body.httpStatus!==200||body.role!=='agent'||body.ownerId!==expectedOwnerId||!uuidPattern.test(body.workspaceId??'')||!agentPattern.test(body.agentId??'')||!Number.isSafeInteger(body.generation)||body.generation<1||body.network!=='stellar:testnet'||expectedGeneration!==undefined&&body.generation!==expectedGeneration||verifiedIdentity&&(body.generation!==verifiedIdentity.generation||body.agentId!==verifiedIdentity.agentId||body.workspaceId!==verifiedIdentity.workspaceId))fail('AGENT_IDENTITY_MISMATCH');
  verifiedIdentity={ownerId:body.ownerId,workspaceId:body.workspaceId,agentId:body.agentId,generation:body.generation,role:'agent',network:'stellar:testnet'};return {...verifiedIdentity};
 }
 async function ensureIdentity(){if(!verifiedIdentity)await identity();}
 async function capabilities(){await ensureIdentity();const body=await call('get_bazaar_capabilities'),purchases=body.effectiveFeatures?.purchases;if(!object(purchases)||typeof purchases.enabled!=='boolean')fail('AGENT_RESPONSE_REJECTED');return {purchasesEnabled:purchases.enabled};}
 async function history(options={}){
  const page=validateAgentHistoryOptions(options);await ensureIdentity();const body=await call('list_market_orders',page);
  if(body.httpStatus!==200||!Array.isArray(body.orders)||body.orders.length>page.limit||typeof body.partialResults!=='boolean'||body.nextCursor!==null&&(typeof body.nextCursor!=='string'||!/^[a-zA-Z0-9_-]{1,512}$/.test(body.nextCursor))||body.partialResults!==(body.nextCursor!==null)||body.orders.some(order=>!object(order)||!uuidPattern.test(order.operationId??'')||order.buyerOwnerId!==expectedOwnerId&&order.sellerOwnerId!==expectedOwnerId||order.perspective!==(order.buyerOwnerId===expectedOwnerId?'purchase':'sale')))fail('AGENT_HISTORY_RESPONSE_REJECTED');
  return {orders:body.orders,nextCursor:body.nextCursor,partialResults:body.partialResults};
 }
 function serial(action){const task=operationTail.then(()=>{assertOpen();return action();}).catch(error=>{throw stop(error);});operationTail=task.then(()=>{},()=>{});return task;}
 return Object.freeze({identity:()=>serial(identity),capabilities:()=>serial(capabilities),history:options=>{validateAgentHistoryOptions(options);return serial(()=>history(options));},check:()=>serial(async()=>{await identity();const status=await capabilities(),page=await history({limit:1});return {identityVerified:true,purchasesEnabled:status.purchasesEnabled,historyCount:page.orders.length,nextCursorPresent:page.nextCursor!==null};}),async close(){await operationTail;await drain();closed=true;await client.close().catch(()=>{});await drain();token='';verifiedIdentity=undefined;}});
}
