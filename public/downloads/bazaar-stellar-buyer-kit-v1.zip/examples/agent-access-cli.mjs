import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {readPrivateInput} from './buyer-private-input.mjs';
import {AGENT_ACCESS_ORIGIN,AgentAccessError,agentAccessOrigin,createAgentAccessClient,validateAgentHistoryOptions} from './agent-access-client.mjs';

const fail=code=>{throw new AgentAccessError(code);};
export function parseAgentAccessArguments(argv=[]){
 if(!Array.isArray(argv)||argv.some(value=>typeof value!=='string'))fail('AGENT_ACCESS_ARGUMENTS_REJECTED');
 const args=[...argv],command=args[0]&&!args[0].startsWith('--')?args.shift():'check';if(!['check','history'].includes(command))fail('AGENT_ACCESS_COMMAND_REJECTED');
 const flags={};const booleans=new Set(['--connect','--secret-stdin']),values=new Set(['--origin','--expected-owner','--expected-generation','--limit','--cursor']);
 for(let index=0;index<args.length;index++){const flag=args[index];if(Object.hasOwn(flags,flag)||!booleans.has(flag)&&!values.has(flag))fail('AGENT_ACCESS_ARGUMENTS_REJECTED');if(booleans.has(flag))flags[flag]=true;else{const value=args[++index];if(value===undefined||value.startsWith('--'))fail('AGENT_ACCESS_ARGUMENTS_REJECTED');flags[flag]=value;}}
 const origin=agentAccessOrigin(flags['--origin']??AGENT_ACCESS_ORIGIN),expectedOwnerId=flags['--expected-owner'];
 if(expectedOwnerId!==undefined&&!/^ow_[a-f0-9]{32}$/.test(expectedOwnerId))fail('AGENT_EXPECTED_OWNER_REQUIRED');
 let expectedGeneration;if(flags['--expected-generation']!==undefined){if(!/^[1-9]\d{0,15}$/.test(flags['--expected-generation']))fail('AGENT_GENERATION_REJECTED');expectedGeneration=Number(flags['--expected-generation']);if(!Number.isSafeInteger(expectedGeneration))fail('AGENT_GENERATION_REJECTED');}
 if(command==='check'&&(flags['--limit']!==undefined||flags['--cursor']!==undefined))fail('AGENT_ACCESS_ARGUMENTS_REJECTED');
 if(flags['--limit']!==undefined&&!/^[1-9]\d?$/.test(flags['--limit']))fail('AGENT_HISTORY_OPTIONS_REJECTED');
 const page=validateAgentHistoryOptions({limit:flags['--limit']===undefined?10:Number(flags['--limit']),...(flags['--cursor']===undefined?{}:{cursor:flags['--cursor']})});
 if(flags['--connect']&&!expectedOwnerId)fail('AGENT_EXPECTED_OWNER_REQUIRED');
 return {command,origin,expectedOwnerId,expectedGeneration,connect:flags['--connect']===true,secretStdin:flags['--secret-stdin']===true,page};
}

/** Default is a local plan: no secret input, SDK session, account or request. */
export async function main(argv=process.argv.slice(2),{input=process.stdin,output=process.stdout,errorOutput=process.stderr,fetchImpl,readPrivateInputImpl=readPrivateInput,createClient=createAgentAccessClient}={}){
 if(Number(process.versions.node.split('.')[0])<24)fail('NODE_24_REQUIRED');
 const options=parseAgentAccessArguments(argv);
 if(!options.connect){const plan={status:'PREPARED_AGENT_ACCESS_ONLY',command:options.command,origin:options.origin,networkEnabled:false,expectedOwnerRequired:true,secretReads:0,networkRequests:0,signatures:0,payments:0};output.write(JSON.stringify(plan)+'\n');return plan;}
 let client,agentAccess,privateValue;
 try{
  if(options.secretStdin&&input.isTTY)fail('PRIVATE_PIPE_REQUIRED');
  const bytes=await readPrivateInputImpl({prompt:'Agent access: ',input,output:errorOutput,maxBytes:2048,allowPipe:options.secretStdin});
  try{
   if(!Buffer.isBuffer(bytes)||bytes.length>2048)fail('AGENT_PRIVATE_INPUT_REJECTED');
   if(options.secretStdin){try{privateValue=JSON.parse(bytes.toString('utf8'));}catch{fail('AGENT_PRIVATE_INPUT_REJECTED');}if(!privateValue||typeof privateValue!=='object'||Array.isArray(privateValue)||Object.keys(privateValue).join(',')!=='agentAccess')fail('AGENT_PRIVATE_INPUT_REJECTED');agentAccess=privateValue.agentAccess;}
   else agentAccess=bytes.toString('utf8');
  }finally{bytes?.fill?.(0);}
  if(typeof agentAccess!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(agentAccess))fail('AGENT_PRIVATE_INPUT_REJECTED');
  client=createClient({origin:options.origin,agentAccess,expectedOwnerId:options.expectedOwnerId,...(options.expectedGeneration===undefined?{}:{expectedGeneration:options.expectedGeneration}),...(fetchImpl===undefined?{}:{fetchImpl})});
  const result=options.command==='check'?await client.check():await client.history(options.page);
  output.write(JSON.stringify({ok:true,...result})+'\n');return result;
 }finally{agentAccess=undefined;if(privateValue)delete privateValue.agentAccess;await client?.close().catch(()=>{});}
}

if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url)main().catch(error=>{const code=error instanceof AgentAccessError?error.code:'AGENT_ACCESS_COMMAND_UNCONFIRMED';console.error(JSON.stringify({ok:false,code,...(error instanceof AgentAccessError&&error.httpStatus!==undefined?{httpStatus:error.httpStatus}:{}),...(error instanceof AgentAccessError&&error.retryAfter!==undefined?{retryAfter:error.retryAfter}:{}),automaticRetry:false}));process.exitCode=1;});
