# Bazaar Stellar buyer kit v1

This archive implements the specific public contract at https://bazaar.browns.studio/INTEGRATION.md (bazaar.integration/v1). Adapt your own agent to that contract. Public discovery does not grant buyer admission; two external purchases are not currently promised. No live financial acceptance is asserted by packaging tests.

## Contents and provenance

Nine public example modules: six existing modules unchanged, the portable runtime with its history cursor bound aligned to the native API, and two new token-only access modules. The kit includes exact direct dependency versions, a pruned npm v3 dependency lock, token-free public/private MCP configuration, and SHA-256 inventory. The lock retains registry URLs, integrity and resolved dependency metadata from the project's lock, with the complete reachable installed dependency/peer graph. No installation was run during packaging. The public example source retains the project's included Apache-2.0 LICENSE. Dependency licenses remain with their respective authors.

There are no wallet seeds, bearer tokens, signing fixtures, profiles, journals, environment files, node_modules or symlinks. The generic marketplace-x402-buyer module also exports optional DPAPI journal helpers and an alternate user-supplied-runtime entry point; the supported packaged CLI entry is examples/buyer-cli.mjs and does not use either.

## Check agent access and own history without a wallet seed

Use the token-only client for private access checks. It does not open the buyer store, load a seed or signer, create accounts or orders, inspect an individual order, reconcile, sign or pay. Each agent uses its own expected owner and private agent bearer. The candidate identity contract reports the authenticated role; this client rejects human/recovery access, wrong owners and unexpected generations.

Without `--connect`, both commands print a local plan without reading a token or making requests:

    node examples/agent-access-cli.mjs check --expected-owner ow_YOUR_32_LOWERCASE_HEX_OWNER
    node examples/agent-access-cli.mjs history --expected-owner ow_YOUR_32_LOWERCASE_HEX_OWNER --limit 10

After reviewing the plan and a fresh request budget, add `--connect` explicitly. Enter only the agent access through the hidden terminal prompt:

    node examples/agent-access-cli.mjs check --expected-owner ow_YOUR_32_LOWERCASE_HEX_OWNER --connect
    node examples/agent-access-cli.mjs history --expected-owner ow_YOUR_32_LOWERCASE_HEX_OWNER --limit 10 --connect

The owner strings above are explanatory placeholders. `check` verifies the own agent identity, reads effective purchase capabilities and one history page limited to one entry, then prints only `identityVerified`, `purchasesEnabled`, `historyCount` and `nextCursorPresent` (plus `ok`). A closed purchase capability remains false; successful access does not authorize spending. `history` verifies identity and prints the own native order page to your **private local terminal**, including any retained inputs and results. Do not redirect this output to shared logs or paste private results into a public conversation.

Pass `--expected-generation 1` to pin a known current generation. Continue history only with its returned opaque `--cursor` (at most 512 characters) and limit 1–20. Independent agents must not share owners, bearers or history cursors. An explicitly selected private inherited pipe may use `--secret-stdin` with exactly `{"agentAccess":"YOUR_PRIVATE_AGENT_ACCESS"}`; never a seed, passphrase, human/recovery access, argv secret or plaintext credential file. No credentials are included here.

The production target is the exact canonical HTTPS origin; `--origin` permits HTTP loopback only for isolated tests. The SDK performs its static handshake and tools list, then only `get_bazaar_identity`, `get_bazaar_capabilities` and `list_market_orders`. Its optional unsupported SSE GET is answered locally without a native request. Requests are serialized, bounded and never automatically retried. Authentication errors, limits, unavailability, malformed replies and unknown acknowledgements stop the session; make no automatic replacement call.

## Local setup

Verify the external archive SHA-256 manifest and the internal MANIFEST.json. Use Node.js 24.x and npm. From the extracted directory run:

    npm ci --ignore-scripts --no-audit --no-fund

This downloads locked dependencies. Run isolated tests before entering credentials. Register your own workspace at https://bazaar.browns.studio/open and preserve its recovery file. Configure a NEW private directory outside the kit/repository/cloud sync, under an existing owner-only parent:

    node examples/buyer-cli.mjs configure /absolute/private/bazaar-buyer

Enter a 12+ byte store passphrase, your agent bearer and your Testnet seed only through the hidden local terminal. Do not paste secrets into ChatGPT. Optional --secret-stdin accepts an explicitly private inherited pipe backed by a secret manager (password plus only the credentials the command changes). Never use argv, plaintext files, URLs or logs for secrets. The encrypted scrypt/AES-256-GCM store is software custody; its local signer handles the seed in memory.

## Read and prepare (no purchase)

    node examples/buyer-cli.mjs discover
    node examples/buyer-cli.mjs discover SERVICE_ID
    node examples/buyer-cli.mjs prepare /absolute/private/bazaar-buyer SERVICE_ID public-input.json
    node examples/buyer-cli.mjs budget /absolute/private/bazaar-buyer

Discovery spends catalogue allowance. Input must be non-secret and match the selected card. Prepare reads the card and creates an encrypted local intent only. Review its UUID, hash, input, recipient and exact price. Default local ceilings are 0.01 USDC per intent and 0.02 USDC total reservations. --max-price on prepare and budget-increase are explicit owner decisions; neither grants server admission nor clears uncertainty.

## Financial command (separate authorization required)

Only after explicit owner approval, effective admission and fresh capacity:

    node examples/buyer-cli.mjs buy /absolute/private/bazaar-buyer OPERATION_UUID

This creates an order, requests its challenge, reserves spend, signs once and submits once. It uses Stellar Testnet USDC, payload.transaction with a signed address authorization inside transaction XDR, one classic Ed25519 payer and sponsored settlement. Portable max network fee is 1,000,000 stroops (0.1 XLM), separate from USDC. It simulates through the pinned Testnet RPC, never sendTransaction. See the contract for exact asset/network/invocation checks; generic x402 or a different wallet profile is not interchangeable.

## Recover without another payment

    node examples/buyer-cli.mjs inspect /absolute/private/bazaar-buyer OPERATION_UUID
    node examples/buyer-cli.mjs recover /absolute/private/bazaar-buyer OPERATION_UUID
    node examples/agent-access-cli.mjs history --expected-owner ow_YOUR_32_LOWERCASE_HEX_OWNER --limit 10 --connect

These never sign or submit payment. The token-only history command does not inspect an individual order or wake a provider. Existing buyer `inspect` and `recover` commands still use the separately configured buyer runtime; an existing-order read may resume its recorded delivery notice. Keep the UUID, encrypted journal, lock and spend reservation after uncertainty. Do not repeat buy, resign, repost, switch payer, clear a reservation or create a replacement UUID. Corrupt/inconsistent journals require investigation, not auto-repair. The original buyer CLI history command remains available for an existing configured store; its cursor limit is now 512 to match the native API. Visible input/results expire after seven days without read renewal; 202/410/429/503 or missing history never authorizes another payment. Respect Retry-After and avoid rapid polling.

## MCP configuration

mcp.public.json uses the portable Streamable HTTP schema and no auth at /api/chatgpt/mcp. It exposes public catalogue/integration, not private actions. mcp.private.template.json is an illustrative client-specific shape for /api/mcp with NO token; inject your own Authorization bearer through your client's secret manager. Do not import it expecting private access without authentication. Environment-variable interpolation is client-specific and is not assumed or embedded here. Never put a human/recovery key into either connection.

## Required acceptance

Test strict order/card/hash/decimal binding, Testnet asset/network, one exact transfer/address signature, expiry and fee rejection offline. Test lost signer/payment acknowledgement and concurrency with no replay. Check own identity, cross-workspace denial, admission, pagination and retention. Only a separately admitted and approved real test can establish settlement plus delivery. The archive does not execute tests, install, configure, sign or buy automatically.
